/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_342(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_164(unsigned x)
{
    return x + 2999142601U;
}

unsigned getval_262()
{
    return 3347662959U;
}

unsigned getval_478()
{
    return 1656838374U;
}

void setval_371(unsigned *p)
{
    *p = 2421715806U;
}

unsigned addval_295(unsigned x)
{
    return x + 2462290008U;
}

unsigned addval_221(unsigned x)
{
    return x + 3284633672U;
}

unsigned addval_147(unsigned x)
{
    return x + 2462550344U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_241()
{
    return 3286272072U;
}

unsigned getval_149()
{
    return 3531919753U;
}

void setval_296(unsigned *p)
{
    *p = 2496760308U;
}

unsigned addval_479(unsigned x)
{
    return x + 3232027017U;
}

unsigned getval_104()
{
    return 3229929097U;
}

unsigned addval_444(unsigned x)
{
    return x + 3380924073U;
}

unsigned addval_328(unsigned x)
{
    return x + 3227569801U;
}

unsigned addval_426(unsigned x)
{
    return x + 3525886601U;
}

void setval_408(unsigned *p)
{
    *p = 3676360329U;
}

void setval_315(unsigned *p)
{
    *p = 2430634312U;
}

void setval_432(unsigned *p)
{
    *p = 3767091336U;
}

void setval_427(unsigned *p)
{
    *p = 2463205779U;
}

void setval_195(unsigned *p)
{
    *p = 3523793289U;
}

void setval_297(unsigned *p)
{
    *p = 3251735033U;
}

unsigned getval_307()
{
    return 3529556617U;
}

unsigned getval_225()
{
    return 3223372425U;
}

unsigned addval_108(unsigned x)
{
    return x + 3285060002U;
}

void setval_333(unsigned *p)
{
    *p = 3375419785U;
}

unsigned getval_103()
{
    return 3264269961U;
}

void setval_265(unsigned *p)
{
    *p = 3676881545U;
}

unsigned addval_186(unsigned x)
{
    return x + 2464188744U;
}

void setval_129(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_204()
{
    return 3767093966U;
}

unsigned getval_424()
{
    return 3529560457U;
}

unsigned addval_260(unsigned x)
{
    return x + 3526410889U;
}

unsigned getval_485()
{
    return 2430634312U;
}

void setval_180(unsigned *p)
{
    *p = 3531919049U;
}

unsigned getval_234()
{
    return 3465245617U;
}

unsigned addval_498(unsigned x)
{
    return x + 3281044121U;
}

unsigned addval_329(unsigned x)
{
    return x + 2497743176U;
}

unsigned addval_344(unsigned x)
{
    return x + 3222848137U;
}

unsigned addval_418(unsigned x)
{
    return x + 3281044105U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
