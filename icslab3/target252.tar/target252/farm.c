/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_101()
{
    return 3281031384U;
}

unsigned addval_282(unsigned x)
{
    return x + 2455255745U;
}

void setval_336(unsigned *p)
{
    *p = 1483997172U;
}

unsigned getval_227()
{
    return 2462550344U;
}

void setval_420(unsigned *p)
{
    *p = 2425378885U;
}

unsigned getval_397()
{
    return 3284633928U;
}

unsigned getval_373()
{
    return 3284633928U;
}

void setval_332(unsigned *p)
{
    *p = 2496104776U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_461(unsigned *p)
{
    *p = 3285621128U;
}

unsigned getval_352()
{
    return 3281049225U;
}

unsigned addval_107(unsigned x)
{
    return x + 2446756232U;
}

unsigned addval_389(unsigned x)
{
    return x + 2425673353U;
}

void setval_179(unsigned *p)
{
    *p = 3523794441U;
}

void setval_485(unsigned *p)
{
    *p = 2425405825U;
}

unsigned addval_241(unsigned x)
{
    return x + 4056143497U;
}

void setval_162(unsigned *p)
{
    *p = 3767093313U;
}

unsigned getval_271()
{
    return 3677407881U;
}

void setval_463(unsigned *p)
{
    *p = 3525886345U;
}

unsigned addval_105(unsigned x)
{
    return x + 3229928075U;
}

void setval_392(unsigned *p)
{
    *p = 3281043721U;
}

unsigned getval_122()
{
    return 3230979721U;
}

unsigned addval_401(unsigned x)
{
    return x + 3227568777U;
}

void setval_450(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_459()
{
    return 2425667977U;
}

unsigned getval_228()
{
    return 3353381192U;
}

void setval_491(unsigned *p)
{
    *p = 3398040889U;
}

void setval_232(unsigned *p)
{
    *p = 3284240889U;
}

unsigned getval_469()
{
    return 3286288712U;
}

unsigned getval_355()
{
    return 3286273352U;
}

void setval_132(unsigned *p)
{
    *p = 3281043913U;
}

void setval_329(unsigned *p)
{
    *p = 3221801608U;
}

void setval_366(unsigned *p)
{
    *p = 3286280520U;
}

void setval_296(unsigned *p)
{
    *p = 3375942283U;
}

unsigned addval_418(unsigned x)
{
    return x + 3223374473U;
}

unsigned addval_265(unsigned x)
{
    return x + 2464188744U;
}

unsigned addval_150(unsigned x)
{
    return x + 3380920713U;
}

unsigned getval_180()
{
    return 2425673353U;
}

unsigned addval_192(unsigned x)
{
    return x + 3234120073U;
}

void setval_108(unsigned *p)
{
    *p = 2429193605U;
}

unsigned addval_137(unsigned x)
{
    return x + 2430634328U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
